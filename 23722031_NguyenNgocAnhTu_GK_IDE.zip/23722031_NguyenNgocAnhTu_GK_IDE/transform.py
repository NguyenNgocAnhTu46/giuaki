#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests
from bs4 import BeautifulSoup
import time
import random
import re

def clean_text(text):
    """Làm sạch văn bản, loại bỏ khoảng trắng thừa và dấu xuống dòng."""
    if not text:
        return ""
    # Loại bỏ khoảng trắng thừa và dấu xuống dòng
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def get_article_details(article_url):
    """Lấy chi tiết của một bài viết từ URL và làm sạch dữ liệu."""
    try:
        # Thêm khoảng thời gian chờ ngẫu nhiên để tránh bị chặn
        time.sleep(random.uniform(1, 3))
        
        # Gửi request đến bài viết
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(article_url, headers=headers)
        
        if response.status_code != 200:
            print(f"Không thể tải bài viết: {article_url}, mã trạng thái: {response.status_code}")
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Lấy và làm sạch thông tin tác giả
        author = soup.select_one('.author_mail')
        author_name = clean_text(author.text) if author else "Không có thông tin tác giả"
        
        # Lấy và làm sạch thông tin thời gian
        time_element = soup.select_one('.date')
        publish_time = clean_text(time_element.text) if time_element else "Không có thông tin thời gian"
        
        # Lấy và làm sạch tóm tắt
        summary_element = soup.select_one('.description')
        summary = clean_text(summary_element.text) if summary_element else ""
        
        # Lấy và làm sạch nội dung bài viết
        content_elements = soup.select('.fck_detail p')
        content = ' '.join([clean_text(p.get_text()) for p in content_elements])
        
        return {
            'author': author_name,
            'time': publish_time,
            'summary': summary,
            'content': content
        }
    except Exception as e:
        print(f"Lỗi khi xử lý bài viết {article_url}: {e}")
        return None

def crawl_and_clean_vnexpress_ai():
    """Crawl và làm sạch dữ liệu từ các bài viết trên mục AI của VnExpress."""
    url = "https://vnexpress.net/cong-nghe/ai"
    
    try:
        # Gửi request đến trang chủ
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers)
        
        if response.status_code != 200:
            print(f"Không thể tải trang: {url}, mã trạng thái: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Tìm tất cả các bài viết
        articles = soup.select('.item-news')
        
        # Danh sách để lưu thông tin các bài viết
        articles_data = []
        count = 0
        
        # Lặp qua từng bài viết
        for article in articles:
            if count >= 5:  # Chỉ lấy 5 bài viết
                break
                
            # Lấy tiêu đề và URL
            title_element = article.select_one('.title-news a')
            if not title_element:
                continue
                
            title = clean_text(title_element.text)
            article_url = title_element['href']
            
            # Đảm bảo URL đầy đủ
            if not article_url.startswith('http'):
                article_url = 'https://vnexpress.net' + article_url
            
            print(f"Đang xử lý bài viết: {title}")
            
            # Lấy thông tin chi tiết của bài viết và làm sạch
            details = get_article_details(article_url)
            if not details:
                continue
            
            # Lưu thông tin bài viết đã làm sạch
            article_info = {
                'title': title,
                'url': article_url,
                'summary': details.get('summary', ''),
                'time': details.get('time', ''),
                'author': details.get('author', ''),
                'content': details.get('content', '')
            }
            
            articles_data.append(article_info)
            count += 1
        
        # In thông tin chi tiết các bài viết
        print(f"\nĐã thu thập và làm sạch {len(articles_data)} bài viết:")
        for i, article in enumerate(articles_data, 1):
            print(f"\n--- Bài viết {i} ---")
            print(f"Tiêu đề: {article['title']}")
            print(f"URL: {article['url']}")
            print(f"Tóm tắt: {article['summary']}")
            print(f"Thời gian: {article['time']}")
            print(f"Tác giả: {article['author']}")
            
            # In phần đầu của nội dung để kiểm tra
            content_preview = article['content'][:150] + "..." if len(article['content']) > 150 else article['content']
            print(f"Nội dung (xem trước): {content_preview}")
        
        return articles_data
        
    except Exception as e:
        print(f"Lỗi khi crawl và làm sạch dữ liệu: {e}")
        return []

if __name__ == "__main__":
    print("Bắt đầu crawl và làm sạch dữ liệu từ VnExpress AI...")
    crawl_and_clean_vnexpress_ai()
    print("\nHoàn thành quá trình crawl và làm sạch dữ liệu.")


# In[ ]:




