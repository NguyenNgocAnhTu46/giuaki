#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests
from bs4 import BeautifulSoup
import csv
import datetime
import time
import random

def get_article_details(article_url):
    """Lấy chi tiết của một bài viết từ URL."""
    try:
        # Thêm khoảng thời gian chờ ngẫu nhiên để tránh bị chặn
        time.sleep(random.uniform(1, 3))
        
        # Gửi request đến bài viết
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(article_url, headers=headers)
        
        if response.status_code != 200:
            print(f"Không thể tải bài viết: {article_url}, mã trạng thái: {response.status_code}")
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Lấy tác giả
        author = soup.select_one('.author_mail')
        author_name = author.text.strip() if author else "Không có thông tin tác giả"
        
        # Lấy thời gian
        time_element = soup.select_one('.date')
        publish_time = time_element.text.strip() if time_element else "Không có thông tin thời gian"
        
        # Lấy tóm tắt
        summary_element = soup.select_one('.description')
        summary = summary_element.text.strip() if summary_element else ""
        
        return {
            'author': author_name,
            'time': publish_time,
            'summary': summary
        }
    except Exception as e:
        print(f"Lỗi khi xử lý bài viết {article_url}: {e}")
        return None

def crawl_vnexpress_ai():
    """Crawl các bài viết từ mục AI của VnExpress."""
    url = "https://vnexpress.net/cong-nghe/ai"
    
    try:
        # Gửi request đến trang chủ
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers)
        
        if response.status_code != 200:
            print(f"Không thể tải trang: {url}, mã trạng thái: {response.status_code}")
            return
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Tìm tất cả các bài viết
        articles = soup.select('.item-news')
        
        # Danh sách để lưu thông tin các bài viết
        articles_data = []
        count = 0
        
        # Lặp qua từng bài viết
        for article in articles:
            if count >= 5:  # Chỉ lấy 5 bài viết
                break
                
            # Lấy tiêu đề và URL
            title_element = article.select_one('.title-news a')
            if not title_element:
                continue
                
            title = title_element.text.strip()
            article_url = title_element['href']
            
            # Đảm bảo URL đầy đủ
            if not article_url.startswith('http'):
                article_url = 'https://vnexpress.net' + article_url
            
            print(f"Đang xử lý bài viết: {title}")
            
            # Lấy thông tin chi tiết của bài viết
            details = get_article_details(article_url)
            if not details:
                continue
            
            # Lưu thông tin bài viết
            article_info = {
                'title': title,
                'url': article_url,
                'summary': details.get('summary', ''),
                'time': details.get('time', ''),
                'author': details.get('author', '')
            }
            
            articles_data.append(article_info)
            count += 1
        
        # Lưu dữ liệu vào file CSV
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"vnexpress_ai_articles_{timestamp}.csv"
        
        with open(csv_filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['title', 'url', 'summary', 'time', 'author']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for article in articles_data:
                writer.writerow(article)
        
        print(f"Đã crawl {len(articles_data)} bài viết và lưu vào file {csv_filename}")
        
        # In thông tin các bài viết đã crawl
        for i, article in enumerate(articles_data, 1):
            print(f"\nBài viết {i}:")
            print(f"Tiêu đề: {article['title']}")
            print(f"URL: {article['url']}")
            print(f"Tóm tắt: {article['summary']}")
            print(f"Thời gian: {article['time']}")
            print(f"Tác giả: {article['author']}")
        
    except Exception as e:
        print(f"Lỗi khi crawl dữ liệu: {e}")

if __name__ == "__main__":
    print("Bắt đầu crawl dữ liệu từ VnExpress AI...")
    crawl_vnexpress_ai()


# In[ ]:




